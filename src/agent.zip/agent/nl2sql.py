# import os
# import dotenv
# import ast

# import pymysql
# from typing import Annotated, Literal

# from langchain_core.messages import AIMessage
# from langchain_openai import ChatOpenAI

# from pydantic import BaseModel, Field
# from typing_extensions import TypedDict

# from langgraph.graph import END, StateGraph, START
# from langgraph.graph.message import AnyMessage, add_messages

# from langchain_community.utilities import SQLDatabase
# from typing import Any

# from langchain_core.messages import ToolMessage
# from langchain_core.runnables import RunnableLambda, RunnableWithFallbacks
# from langgraph.prebuilt import ToolNode

# from langchain_community.agent_toolkits import SQLDatabaseToolkit
# from langchain_core.prompts import ChatPromptTemplate

# from langchain_core.tools import tool

# dotenv.load_dotenv()

# model_name = "Qwen/Qwen2.5-Coder-32B-Instruct"
# openai_api_key = os.getenv("MODEL_SCOPE_API_KEY")
# openai_api_base = "https://api-inference.modelscope.cn/v1/"


# # 配置 MySQL 数据库连接信息
# MYSQL_USER = os.getenv("MYSQL_USER", "root")
# MYSQL_PASSWORD = os.getenv("MYSQL_PASSWORD", "<KI*9ol.")
# MYSQL_HOST = os.getenv("MYSQL_HOST", "47.95.220.74")
# MYSQL_PORT = os.getenv("MYSQL_PORT", "13306")
# MYSQL_DATABASE = os.getenv("MYSQL_DATABASE", "fozhao")

# # 构建 MySQL 连接字符串
# MYSQL_CONNECTION_STRING = f"mysql+mysqlconnector://{MYSQL_USER}:{MYSQL_PASSWORD}@{MYSQL_HOST}:{MYSQL_PORT}/{MYSQL_DATABASE}"

# # 初始化数据库连接
# db = SQLDatabase.from_uri(MYSQL_CONNECTION_STRING)

# def get_mysql_table_schema(table_name: str) -> str:
#     try:
#         # 连接到 MySQL 数据库
#         connection = pymysql.connect(
#             host=MYSQL_HOST,
#             port=int(MYSQL_PORT),
#             user=MYSQL_USER,
#             password=MYSQL_PASSWORD,
#             database=MYSQL_DATABASE
#         )

#         # 创建游标对象
#         with connection.cursor() as cursor:
#             sql_query = f"SHOW CREATE TABLE {table_name}"
#             cursor.execute(sql_query)
            
#             # 获取完整结果
#             result = cursor.fetchone()
#             if result:
#                 return f"表名: {table_name}\n{result[1]}"  # result[1] 是完整的建表语句
#             else:
#                 return f"表名: {table_name}\n未找到表的创建语句。"

#     except pymysql.MySQLError as e:
#         return f"表名: {table_name}\n数据库错误: {e}"

#     finally:
#         if 'connection' in locals() and connection.open:
#             connection.close()

# def create_tool_node_with_fallback(tools: list) -> RunnableWithFallbacks[Any, dict]:
#     """
#     创建一个具有回退功能的ToolNode来处理错误并将其显示给代理。
#     """
#     return ToolNode(tools).with_fallbacks(
#         [RunnableLambda(handle_tool_error)], exception_key="error"
#     )

# def handle_tool_error(state) -> dict:
#     error = state.get("error")
#     tool_calls = state["messages"][-1].tool_calls
#     return {
#         "messages": [
#             ToolMessage(                                                                                                                                                                      content=f"Error: {repr(error)}\n please fix your mistakes.",
#                 tool_call_id=tc["id"],
#             )
#             for tc in tool_calls
#         ]
#     }

# # toolkit = SQLDatabaseToolkit(db=db, llm=ChatOpenAI(model=model_name, openai_api_key=openai_api_key, openai_api_base=openai_api_base))
# # tools = toolkit.get_tools()
# # get_schema_tool = next(tool for tool in tools if tool.name == "sql_db_schema")

# @tool
# def db_query_tool(query: str) -> str:
#     """
#     对数据库执行SQL查询并返回结果。
#     如果查询不正确，将返回错误消息，并以 Error: 开头。
#     如果查询没有返回数据，将返回空结果集。
#     如果返回错误，请重写查询，检查查询，然后重试。
#     """
#     try:
#         result = db.run_no_throw(query)
#         if result is None:
#             return "Error: 查询失败. 请重写您的查询，然后重试"
#         if result == [] or result == "":
#             return "查询结果为空，没有找到匹配的数据。"
#         return result
#     except Exception as e:
#         return f"Error: {str(e)}. 请重写您的查询，然后重试。"

# @tool
# def db_table_comment_tool() -> str:
#     """
#     获取数据库中所有表的名称和注释。
#     """
#     query = """
#     SELECT 
#         TABLE_NAME as table_name,
#         TABLE_COMMENT as table_comment
#     FROM 
#         information_schema.TABLES 
#     WHERE 
#         TABLE_SCHEMA = 'fozhao'
#     """
#     result = db.run(query, fetch="all")

#     # 将字符串解析为Python列表
#     data = ast.literal_eval(result)

#     # 初始化结果字符串
#     data_result = ""

#     # 遍历并格式化拼接字符串
#     for table_name, table_description in data:
#         data_result += f"表名：{table_name} 表说明：{table_description}\n"

#     return data_result

# @tool
# def db_table_schema_tool(table_names: str) -> str:
#     """
#     获取数据库中指定表的表结构。
#     """

#     result = ""

#     for table_name in table_names.split(','):
#         temp = get_mysql_table_schema(table_name.strip())
#         result += temp + '\n'

#     return result

# print(db_table_schema_tool.invoke("bak_commercial_division_attendance"))

# query_check_system = """你是一位注重细节的 SQL 专家。
# 仔细检查以下 MySQL 查询是否存在常见错误，包括：
# - 在含有 NULL 值的情况下使用 NOT IN
# - 应使用 UNION ALL 时却使用了 UNION
# - 使用 BETWEEN 表示不包含边界的范围
# - 谓词中的数据类型不匹配
# - 正确引用标识符
# - 函数参数数量正确
# - 转换为正确的数据类型
# - 使用正确的列进行连接

# 如果发现上述任何错误，请重写查询。如果没有错误，则只需复现原始查询。

# 你将在完成此检查后调用适当的工具来执行查询。"""

# query_check_prompt = ChatPromptTemplate.from_messages(
#     [("system", query_check_system), ("placeholder", "{messages}")]
# )
# query_check = query_check_prompt | ChatOpenAI(model=model_name, temperature=0, openai_api_key=openai_api_key, openai_api_base=openai_api_base).bind_tools(
#     [db_query_tool], tool_choice="required"
# )

# # 定义代理的状态
# class State(TypedDict):
#     messages: Annotated[list[AnyMessage], add_messages]

# # 定义新图形
# workflow = StateGraph(State)

# # 为第一个工具调用添加节点
# def first_tool_call(state: State) -> dict[str, list[AIMessage]]:
#     return {
#         "messages": [
#             AIMessage(
#                 content="",
#                 tool_calls=[
#                     {
#                         "name": "db_table_comment_tool",
#                         "args": {},
#                         "id": "tool_abcd123",
#                     }
#                 ],
#             )
#         ]
#     }


# def model_check_query(state: State) -> dict[str, list[AIMessage]]:
#     """
#     使用此工具检查查询是否正确，然后再执行它。
#     """
#     return {"messages": [query_check.invoke({"messages": [state["messages"][-1]]})]}

# workflow.add_node("first_tool_call", first_tool_call)

# # 为前两个工具添加节点
# workflow.add_node(
#     "list_tables_tool", create_tool_node_with_fallback([db_table_comment_tool])
# )
# workflow.add_node("get_schema_tool", create_tool_node_with_fallback([db_table_schema_tool]))

# # 为模型添加一个节点，以便根据问题和可用表选择相关表
# model_get_schema = ChatOpenAI(model=model_name, temperature=0,openai_api_key=openai_api_key,openai_api_base=openai_api_base).bind_tools(
#     [db_table_schema_tool]
# )
# workflow.add_node(
#     "model_get_schema",
#     lambda state: {
#         "messages": [model_get_schema.invoke(state["messages"])],
#     },
# )

# # 描述一个表示结束状态的工具
# class SubmitFinalAnswer(BaseModel):
#     """根据查询结果向用户提交最终答案."""
#     final_answer: str = Field(..., description="向用户展示的最终答案")

# # 为模型添加一个节点，以根据问题和模式生成查询
# query_gen_system = """你是一位注重细节的 SQL 专家。

# 给定一个输入问题，生成一个语法正确的 MySQL 查询并运行，然后查看查询结果并返回答案。

# 除了使用 SubmitFinalAnswer 提交最终答案外，不要调用任何其他工具。

# 在生成查询时：
# - 输出能够回答输入问题的 SQL 查询，无需包含工具调用。
# - 除非用户明确指定了希望获取的示例数量，否则始终将查询结果限制为最多 5 条。
# - 你可以按相关列对结果进行排序，以返回数据库中最有趣或最相关的示例。
# - 切勿从特定表中查询所有列，仅请求与问题相关的列。

# 不要使用示例数据，直接生成SQL语句
# 如果在执行查询时遇到错误，请重写查询并再次尝试。
# 如果查询结果为空集，请尝试重写查询以获得非空结果集。
# 如果信息不足，无法回答问题，请直接说明信息不足，切勿捏造内容。
# 如果你有足够的信息来回答输入问题，请直接调用SubmitFinalAnswer工具提交最终答案。

# 切勿对数据库执行任何数据操作语句（如 INSERT、UPDATE、DELETE、DROP 等）。"""

# # query_gen_system = """You are a SQL expert with a strong attention to detail.

# # Given an input question, output a syntactically correct SQLite query to run, then look at the results of the query and return the answer.

# # DO NOT call any tool besides SubmitFinalAnswer to submit the final answer.

# # When generating the query:

# # Output the SQL query that answers the input question without a tool call.

# # Unless the user specifies a specific number of examples they wish to obtain, always limit your query to at most 5 results.
# # You can order the results by a relevant column to return the most interesting examples in the database.
# # Never query for all the columns from a specific table, only ask for the relevant columns given the question.

# # If you get an error while executing a query, rewrite the query and try again.

# # If you get an empty result set, you should try to rewrite the query to get a non-empty result set. 
# # NEVER make stuff up if you don't have enough information to answer the query... just say you don't have enough information.

# # If you have enough information to answer the input question, simply invoke the appropriate tool to submit the final answer to the user.

# # DO NOT make any DML statements (INSERT, UPDATE, DELETE, DROP etc.) to the database."""


# query_gen_prompt = ChatPromptTemplate.from_messages(
#     [("system", query_gen_system), ("placeholder", "{messages}")]
# )
# query_gen = query_gen_prompt | ChatOpenAI(model=model_name, temperature=0,openai_api_key=openai_api_key,openai_api_base=openai_api_base).bind_tools(
#     [SubmitFinalAnswer]
# )

# def query_gen_node(state: State):
#     """
#     生成 SQL 查询并返回结果
#     """
#     message = query_gen.invoke(state)

#     # 检查是否有工具调用
#     tool_messages = []
#     if message.tool_calls:
#         for tc in message.tool_calls:
#             if tc["name"] != "SubmitFinalAnswer" and tc["name"] != "db_table_schema_tool":
#                 tool_messages.append(
#                     ToolMessage(
#                         content=f"Error: 调用了错误的工具：{tc['name']}。请修正你的错误。记住，只能调用 SubmitFinalAnswer 来提交最终答案。生成的查询应该在没有工具调用的情况下输出。",
#                         tool_call_id=tc["id"],
#                     )
#                 )
#     else:
#         tool_messages = []
#     return {"messages": [message] + tool_messages}
   

# workflow.add_node("query_gen", query_gen_node)

# # 为模型添加一个节点，以便在执行查询之前对其进行检查
# workflow.add_node("correct_query", model_check_query)

# # 添加用于执行查询的节点
# workflow.add_node("execute_query", create_tool_node_with_fallback([db_query_tool]))

# # 定义条件边以决定是继续还是结束工作流
# def should_continue(state: State) -> Literal[END, "correct_query", "query_gen"]:
#     """
#     决定工作流是继续还是结束
#     """
#     messages = state["messages"]
#     last_message = messages[-1]
    
#     # 如果有工具调用，则结束
#     if getattr(last_message, "tool_calls", None)  and last_message.tool_calls[0]["name"] != "db_table_schema_tool":
#         return END
    
#     # 如果有错误消息，则重新生成查询
#     if last_message.content.startswith("Error:"):
#         return "query_gen"
    
#     # 否则，检查查询
#     return "correct_query"


# # 指定节点之间的边
# workflow.add_edge(START, "first_tool_call")
# workflow.add_edge("first_tool_call" , "list_tables_tool")
# workflow.add_edge("list_tables_tool", "model_get_schema")
# workflow.add_edge("model_get_schema", "get_schema_tool")
# workflow.add_edge("get_schema_tool", "query_gen")
# workflow.add_conditional_edges(
#     "query_gen",
#     should_continue,
# )
# workflow.add_edge("correct_query", "execute_query")
# workflow.add_edge("execute_query", "query_gen")

# # 将工作流编译为可运行的
# nl2sql_agent = workflow.compile(name="NL2SQL")