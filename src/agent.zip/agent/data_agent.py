# import os
# import dotenv

# from langchain_core.tools import tool
# from langgraph.prebuilt import create_react_agent
# from langgraph.config import get_stream_writer
# from langchain_openai import ChatOpenAI

# from agent.nl2sql import nl2sql_agent
# dotenv.load_dotenv()

# @tool
# def query_data(question: str) -> str:
#     """Query data.

#     Args:
#         question (str): 用于生成SQL语句的问题。
#     """
#     writer = get_stream_writer()
#     writer({"action": "检索数据"})

#     result = nl2sql_agent.invoke({"messages": question})

#     writer({"action": "检索数据"})
#     return result["messages"][-1].content


# data_agent = create_react_agent(
#     model=ChatOpenAI(
#         model_name="gpt-4o-mini",
#         openai_api_key=os.getenv("OPENAI_API_KEY"),
#         temperature=0.0,
#         tags=["call_data"]
#     ),
#     tools=[query_data],
#     name="data_agent",
#     prompt="""You are a data expert with access to query data.

#     You can use the following tools to help you:
#     - query_data(query): to query data.
#     """
# )

