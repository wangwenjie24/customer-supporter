import os
import dotenv

from typing import Literal

from langgraph.checkpoint.memory import MemorySaver
from langgraph.types import Command
from langgraph.graph import StateGraph

from agent.corporate_legal_agent import corporate_legal_agent
from agent.configuration import Configuration
from agent.hr_agent import hr_agent
from agent.financial_agent import financial_agent
from agent.state import State

dotenv.load_dotenv()


def router(state: State) -> Command[Literal["hr_agent", "financial_agent", "corporate_legal_agent"]]:
    last_message = state.messages[-1]

    if state.action == "hr_agent":
        # control flow
        goto="hr_agent"
    elif state.action == "financial_agent":
        goto="financial_agent"
    elif state.action == "corporate_legal_agent":
        goto="corporate_legal_agent"
    else:
        raise ValueError(f"Invalid action: {state.action}")

    return Command(
        # state update
        update={"messages": last_message},
        # control flow
        goto=goto
    )

builder = StateGraph(State, config_schema=Configuration)
builder.add_node("router", router)
builder.add_node("hr_agent", hr_agent)
builder.add_node("financial_agent", financial_agent)
builder.add_node("corporate_legal_agent", corporate_legal_agent)

builder.add_edge("__start__", "router")
builder.add_edge("hr_agent", "__end__")
builder.add_edge("financial_agent", "__end__")
builder.add_edge("corporate_legal_agent", "__end__")

# Compile and run
checkpointer = MemorySaver()
graph = builder.compile(checkpointer=checkpointer)
graph.name = "Customer Supporter" 

# "请站在甲方角度分析以下合同文本中的法律风险。合同路径：http://47.251.17.61/saiyan-ai/system/file/downloadById?id=1914982139343204352"

# if __name__ == "__main__":
#     inputs = {"messages": [("user", "你是谁？")], "action": "hr_agent"}
#     current_agent = None
#     for stream_mode, streamed_output in graph.stream(inputs, stream_mode=["messages", "custom"], config={"configurable": {"thread_id": "2", "user_id": "10001", "user_title": "万书记"}}):
#         # 如果是代理的消息，显示代理名称和内容

#         if stream_mode == "custom":
#             print(streamed_output)
#         print(streamed_output)
#         # if stream_mode == "messages" and isinstance(streamed_output, tuple) and len(streamed_output) > 1:
#         #     chunk, metadata = streamed_output
#         #     if metadata.get("langgraph_node", "") == "agent":
#         #         print(chunk.content, end="", flush=True)
#         # if stream_mode == "messages" and isinstance(streamed_output, tuple) and len(streamed_output) > 1:
#         #     chunk, metadata = streamed_output
#         #     if isinstance(chunk, AIMessageChunk) and chunk.content and "call_supervisor" not in metadata.get("tags", []) and "call_analyze_contract_risk" not in metadata.get("tags", []):
#         #         print(chunk.content, end="", flush=True)