# import os
# import dotenv

# from langgraph_supervisor import create_supervisor
# from langgraph.checkpoint.memory import MemorySaver
# from langchain_core.messages import AIMessageChunk
# from langchain_openai import ChatOpenAI
# from langchain_core.runnables import RunnableConfig

# from agent.data_agent import data_agent
# from agent.corporate_legal_agent import corporate_legal_agent
# from agent.configuration import Configuration
# from agent.hr_agent import hr_agent
# from agent.financial_agent import financial_agent
# from agent.prompts import supervisor_prompt

# dotenv.load_dotenv()

# # 修改您的代码以格式化supervisor_prompt
# def get_formatted_supervisor_prompt(config: RunnableConfig):
#     configuration = Configuration.from_runnable_config(config)
#     user_title = configuration.user_title

    
#     # 格式化supervisor_prompt
#     return supervisor_prompt.format(user_title=user_title)

# # Create supervisor workflow
# workflow = create_supervisor(
#     [hr_agent, financial_agent, corporate_legal_agent],
#     model=ChatOpenAI(
#         model_name="gpt-4o-mini",
#         openai_api_key=os.getenv("OPENAI_API_KEY"),
#         temperature=0.0,
#         tags=["call_supervisor"]
#     ),
#     prompt=supervisor_prompt,
#     output_mode="last_message",
#     config_schema=Configuration,
#     add_handoff_back_messages=False
# )

# # Compile and run
# checkpointer = MemorySaver()
# graph = workflow.compile(checkpointer=checkpointer)
# graph.name = "Customer Supporter" 

# # "请站在甲方角度分析以下合同文本中的法律风险。合同路径：http://47.251.17.61/saiyan-ai/system/file/downloadById?id=1914982139343204352"

# # if __name__ == "__main__":
# #     inputs = {"messages": [("user", "请站在甲方角度分析以下合同文本中的法律风险。合同路径：http://47.251.17.61/saiyan-ai/system/file/downloadById?id=1914991466145705984")]}
# #     current_agent = None
# #     for stream_mode, streamed_output in graph.stream(inputs, stream_mode=["messages", "custom"], config={"configurable": {"thread_id": "2", "user_id": "10001", "user_title": "万书记"}}):
# #         # 如果是代理的消息，显示代理名称和内容

# #         if stream_mode == "custom":
# #             print(streamed_output)

# #         if stream_mode == "messages" and isinstance(streamed_output, tuple) and len(streamed_output) > 1:
# #             chunk, metadata = streamed_output
# #             if isinstance(chunk, AIMessageChunk) and chunk.content and "call_supervisor" not in metadata.get("tags", []) and "call_analyze_contract_risk" not in metadata.get("tags", []):
# #                 print(chunk.content, end="", flush=True)