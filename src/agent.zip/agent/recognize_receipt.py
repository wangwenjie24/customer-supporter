# """Define a simple chatbot agent.

# This agent returns a predefined response without using an actual LLM.
# """

# import json
# import os
# import dotenv

# from langchain_core.runnables import RunnableConfig
# from langgraph.graph import StateGraph
# from langchain_core.messages import HumanMessage
# from langchain_openai import ChatOpenAI
# from langchain_core.messages import SystemMessage
# from typing import Literal

# from agent.configuration import Configuration
# from agent.state import State, InputState, OutputState
# from agent.prompts import extractor_instructions, categorizer_instructions
# from agent.utils import image_to_base64

# dotenv.load_dotenv()

# min_pixels=128*28*28
# max_pixels=4096*28*28

# # Initialize the processable kinds
# llm = ChatOpenAI(
#     model_name="Qwen/Qwen2.5-VL-72B-Instruct",
#     # model_name="qwen2.5-vl-72b-instruct",
#     openai_api_key=os.getenv("MODEL_SCOPE_API_KEY"),
#     openai_api_base=os.getenv("MODEL_SCOPE_API_BASE"),
#     temperature=0.0
# )

# config = {
# 	"air_transport_receipt": {
# 		"feature": "It contains information such as serial number, passenger name, valid ID number, carrier, flight number, seat level, date, and time",
# 		"rules": [
# 			"For ´fare´, ´civil_aviation_development_fund´ and ´total´: remove 'CN' or 'CNY' prefix and any spaces, keep original numbers",
# 			"For ´fuel_surcharge´: should start with 'YQ', remove 'YQ' prefix and any spaces, keep original numbers'",
# 			"For ´other_taxes´: it is a number, keep original numbers",
#             "For all amounts: keep only digits and decimal point"
# 		],
# 		"output_format": {
# 			"title": "标题",
# 			"serial_number": "SERIAL NUMBER印刷字号",
# 			"passenger_name": "旅客姓名",
# 			"valid_id_no": "有效身份证件号码",
# 			"endorsements": "签注",
# 			"from": "自FROM",
# 			"to": "至TO",
# 			"carrier": "承运人",
# 			"flight_number": "航班号",
# 			"class": "座位等级",
# 			"date": "日期",
# 			"time": "时间",
# 			"fare_basis": "客票级别/客票类别",
# 			"not_valid_before": "客票生效日期",
# 			"not_valid_after": "有效期截止日期",
# 			"free_baggage_allowance": "免费行李",
# 			"fare": "票价",
# 			"civil_aviation_development_fund": "民航发展基金",
# 			"fuel_surcharge": "燃油附加费",
# 			"other_taxes": "其他税费",
# 			"total": "合计",
# 			"e-ticket_number": "电子客票号码",
# 			"check_code": "验证码",
# 			"information": "提示信息",
# 			"insurance_fee": "保险费",
# 			"sales_agent_code": "销售单位代号",
# 			"issued_by": "填开单位",
# 			"issue_date": "填开日期"
# 		},
# 		"examples": [
#             "{'类型': '航空运输电子客票单', 'SERIAL NUMBER印刷字号':'55507095700','旅客姓名':'李博文','有效身份证件号码':'152127199408093011','签注':'Q/9HE10RV5/不得签转/改退收费','承运人':'国航','航班号':'CA8156','自FROM':'锡林浩特','至TO':'呼和浩特-白塔','座位等级':'W','日期':'2024-07-03','时间':'09:25','客票级别/客票类别':'W','客票生效日期':'','有效期截止日期':'25JUN','免费行李':'20K','票价':'610.00 CNY','民航发展基金':'EXEMPT YQ','燃油附加费':'30.00','其他税费':'','合计':'640.00 CNY','电子客票号码':'9995480673574','验证码':'9570','提示信息':'','保险费':'XXX','销售单位代号':'CAN 532 08351991','填开单位':'广州嘉宝商旅技术服务有限公司','填开日期':'2024-07-04'}",
#             "{'类型':'航空运输电子客票行程单','SERIAL NUMBER印刷字号':'55507097236','旅客姓名':'田忠天','有效身份证件号码':'150422199304013913','签注':'不得自愿签转','自FROM':'锡林浩特','至TO':'呼和浩特-白塔','承运人':'天航','航班号':'GS6614','座位等级':'','日期':'2024-07-03','时间':'17:00','客票级别/客票类别':'','客票生效日期':'','有效期截止日期':'','免费行李':'20K','票价':'470.00','民航发展基金':'50.00','燃油附加费':'30.00','其他税费':'','合计':'550.00','电子客票号码':'8265449276436','验证码':'9723','提示信息':'','保险费':'XXX','销售单位代号':'CAN53208351991','填开单位':'广州嘉宝商旅技术服务有限公司','填开日期':'2024-07-04'}"
#         ]
# 	},
# 	"vat_invoice": {
# 		"feature": "It contains information such as the invoice number, date, buyer and seller details, item descriptions, prices, taxes, and totals.",
# 		"rules": [
# 			"For amounts: remove any currency symbols (￥, Y, CN, CNY), spaces and other non-numeric characters before processing, keep only digits and decimal point in the final output, especially for the ´total_amount_including_tax_lowercase´ field"
# 		],
# 		"output_format": {
# 			"title": "发票标题",
# 			"invoice_number": "发票号码",
# 			"issue_date": "开票日期",
# 			"buyer_name": "购买方名称",
# 			"buyer_tax_id": "购买方纳税人识别号",
# 			"buyer_address_phone": "购买方地址、电话",
# 			"buyer_bank_account": "购买方开户行及账号",
# 			"items": [{
# 				"item_name": "货物或应税劳务、服务名称",
# 				"specification": "规格型号",
# 				"unit": "单位",
# 				"quantity": "数量",
# 				"unit_price": "单价",
# 				"amount": "金额",
# 				"tax_rate": "税率",
# 				"tax_amount": "税额"
# 			}],
# 			"total_amount": "合计金额",
# 			"total_tax_amount": "合计税额",
# 			"total_amount_including_tax_capital": "价税合计（大写）",
# 			"total_amount_including_tax_lowercase": "价税合计（小写）",
# 			"seller_name": "销售方名称",
# 			"seller_tax_id": "销售方纳税人识别号",
# 			"seller_address_phone": "销售方地址、电话",
# 			"seller_bank_account": "销售方开户行及账号",
# 			"remarks": "备注",
# 			"payee": "收款人",
# 			"reviewer": "复核",
# 			"issuer": "开票人"
# 		},
# 		"examples": [
# 			"{'title':'北京增值税普通发票','invoice_number':'42129756','issue_date':'2024年03月09日','buyer_name':'内蒙古科电电气有限责任公司','buyer_tax_id':'91150100720175351X','buyer_address_phone':'内蒙古自治区呼和浩特市和林格尔县盛乐经济园区北四街南侧电科院科技园区0471-6226440','buyer_bank_account':'工商银行呼和浩特石羊桥东路支行0602005009024829865','items':[{'item_name':'住宿服务*住宿费','specification':'间','unit':'天','quantity':'3','unit_price':'474.257425742','amount':'1422.77','tax_rate':'1%','tax_amount':'14.23'}],'total_amount':'1422.77','total_tax_amount':'14.23','total_amount_including_tax_capital':'壹仟肆佰叁拾柒圆整','total_amount_including_tax_lowercase':'1437.00','seller_name':'北京富国宾馆有限公司','seller_tax_id':'911101017177635152','seller_address_phone':'北京市东城区北新桥头条56号01084066811','seller_bank_account':'北京银行长城支行营业部01090365000120108081488','remarks':'备注信息','payee':'韩丹','reviewer':'张伟','issuer':'韩晓芸'}",
# 			"{'title':'内蒙古增值税电子专用发票','invoice_number':'12208216','issue_date':'2023年07月15日','buyer_name':'内蒙古科电电气有限责任公司','buyer_tax_id':'91150100720175351X','buyer_address_phone':'呼和浩特市盛乐经济园区北四街南侧电科院科技园区0471-6226140','buyer_bank_account':'工商银行呼和浩特石羊桥东路支行0602005009024829865','items':[{'item_name':'住宿服务*住宿','specification':'标间','unit':'天','quantity':'9','unit_price':'215.811584158416','amount':'1942.57','tax_rate':'1%','tax_amount':'19.43'}],'total_amount':'1942.57','total_tax_amount':'19.43','total_amount_including_tax_capital':'壹仟玖佰陆拾贰圆整','total_amount_including_tax_lowercase':'Y1962.00','seller_name':'乌拉特中旗吴泽酒店宾馆','seller_tax_id':'92150824MA7YQ1EUX0','seller_address_phone':'巴彦淖尔市乌拉特中旗海流图镇13904720084','seller_bank_account':'中国农业银行乌拉特中旗支行05424101040022794','remarks':'','payee':'牛晓岚','reviewer':'余震','issuer':'海英'}"
# 		]
# 	}
# }

# def categorize(state: State, config: RunnableConfig) -> str:
#     """ Recognize the type based on image content."""

#     # Initialize the processable kinds
#     processable_categories = ""
#     for category, config_data in config.items():
#         processable_categories += category + ": " + config_data["feature"] + "\n"
#     # Get State
#     image_path = state["image_path"]
#     # Format the recognizer instructions
#     categorizer_instructions_formatted  = categorizer_instructions.format(
#         processable_categories=processable_categories
#     )
#     # Call LLM
#     result = llm.invoke([
#         SystemMessage(content=categorizer_instructions_formatted),
#         HumanMessage(content=[{
#             "type": "image_url",
#             "min_pixels": min_pixels,
#             "max_pixels": max_pixels,
#             "image_url": {"url": image_to_base64(image_path)}
#         }])
#     ])
#     return {   "running_category": result.content}


# def router(state: State, config: RunnableConfig) -> Literal["extract", "__end__"]:
#     if state["running_category"] == "unknown":
#         return "__end__"
#     else:
#         return "extract"


# def extract(state: State, config: RunnableConfig) -> str:
#     """Extract data from the document."""
    
#     # Get State
#     image_path = state["image_path"]
#     category = state["running_category"]
#     # Format the extractor instructions
#     extractor_instructions_formatted = extractor_instructions.format(
#         category=category,
#         rules="\n".join(["- " + rule for rule in config[category]["rules"]]),
#         examples=config[category]["examples"]
#     )
#     # Call LLM
#     result = llm.invoke([
#         SystemMessage(content=extractor_instructions_formatted),
#         HumanMessage(content=[{
#             "type": "image_url",
#             "min_pixels": min_pixels,
#             "max_pixels": max_pixels,
#             "image_url": {"url": image_to_base64(image_path)}
#         }])
#     ])
    
#     # 将JSON字符串转换为Python字典对象
#     try:
#         # 尝试解析JSON字符串
#         extracted_data = json.loads()
#         return {"output": result.content}
#     except json.JSONDecodeError:
#         # 如果解析失败，返回原始内容
#         return {"output": result.content}

# # Create the graph
# workflow = StateGraph(
#     State, input=InputState, output=OutputState, config_schema=Configuration
# )
# workflow.add_node("categorize", categorize)
# workflow.add_node("extract", extract)
# workflow.add_edge("__start__", "categorize")
# workflow.add_conditional_edges("categorize", router, {"extract": "extract", "__end__": "__end__"})
# workflow.add_edge("categorize", "extract")
# workflow.add_edge("extract", "__end__")

# graph = workflow.compile(name="recognize_receipt")
