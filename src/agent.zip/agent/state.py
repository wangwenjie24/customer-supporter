"""Define the state structures for the agent."""

from __future__ import annotations

from dataclasses import dataclass
from typing_extensions import Annotated
from langgraph.graph import add_messages
from langchain_core.messages import AnyMessage

@dataclass
class State:
    messages: Annotated[list[AnyMessage], add_messages]
    action: str